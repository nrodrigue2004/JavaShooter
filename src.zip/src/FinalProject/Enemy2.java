package FinalProject;

import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.CollisionEventType;
import basicgraphics.images.Picture;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Timer;
import java.util.TimerTask;

public class Enemy2 extends Sprite {
    private static final double SPEED = 2.0;
    private Player player;

    public Enemy2(SpriteComponent sc, Player player) {
        super(sc);
        this.player = player;
        setPicture(makeDiamond());
        moveEnemy();
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                moveEnemy();
            }
        }, 0, 2000);


        while (true) {
            setX(Game.RAND.nextInt(Game.BOARD_SIZE.width) - Game.SMALL);
            setY(Game.RAND.nextInt(Game.BOARD_SIZE.height) - Game.SMALL);
            if (Math.abs(getX() - Game.BOARD_SIZE.width / 2) < 2 * Game.BIG
                    && Math.abs(getY() - Game.BOARD_SIZE.height / 2) < 2 * Game.BIG) {
            } else {
                break;
            }
        }

        setVel(2 * Game.RAND.nextDouble() - 1, 2 * Game.RAND.nextDouble());
    }

    @Override
    public void processEvent(SpriteCollisionEvent se) {
        super.processEvent(se);

        if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
            if (se.xlo) {
                setX(getWidth());
            }
            if (se.xhi) {
                setX(getSpriteComponent().getSize().width - getWidth());
            }
            if (se.ylo) {
                setY(getHeight());
            }
            if (se.yhi) {
                setY(getSpriteComponent().getSize().height - getHeight());
            }
        }
    }

    public void moveEnemy() {
        chasePlayer();
    }

    private void chasePlayer() {
        double deltaX = player.getX() - getX();
        double deltaY = player.getY() - getY();
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

        if (distance > 0) {
            double dirX = deltaX / distance;
            double dirY = deltaY / distance;
            setVel(dirX * SPEED, dirY * SPEED);
        }
    }

    private Picture makeDiamond() {
        int size = 40;
        BufferedImage diamondImage = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = diamondImage.createGraphics();

        g.setColor(Color.RED);
        int[] xPoints = {size / 2, size, size / 2, 0};
        int[] yPoints = {0, size / 2, size, size / 2};
        g.fillPolygon(xPoints, yPoints, 4);

        return new Picture(diamondImage);
    }
}
