package FinalProject;

import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Player extends Sprite {
    private boolean invincible = false;
    private static final int INVINCIBILITY_DURATION = 10000;
    static final double PLAYER_SPEED = .5;
    private int velX = 0;
    private int velY = 0;
    private int levelUpPoints;
    private double playerSpeed;
    private double shootSpeed;
    static int shieldStrength;


    public Player(SpriteComponent sc) {
        super(sc);
        setPicture(Game.makeBall(Game.SHOOTER_COLOR, Game.BIG));
        setX(Game.BOARD_SIZE.width / 2);
        setY(Game.BOARD_SIZE.height / 2);
        levelUpPoints = 0;
        playerSpeed = 1.0;
        shootSpeed = 2.0;
        shieldStrength = 0;
    }


    public void move() {
        setX(getX() + velX * PLAYER_SPEED);
        setY(getY() + velY * PLAYER_SPEED);
    }


    public void setVelX(int velX) {
        this.velX = velX;
    }


    public void setVelY(int velY) {
        this.velY = velY;
    }

    public void resetPosition() {
        setX(Game.BOARD_SIZE.width / 2);
        setY(Game.BOARD_SIZE.height / 2);
    }

    public void upgradeAttribute(String attribute) {
        if (levelUpPoints > 0) {
            switch (attribute) {
                case "Player Speed":
                    playerSpeed += 0.5;
                    break;
                case "Bullet Speed":
                    shootSpeed += 1;
                    break;
                case "Shield Strength":
                    shieldStrength++;
                    break;
                default:
                    break;
            }
            levelUpPoints--;
        }
    }

    public void earnLevelUpPoint() {
        levelUpPoints++;
    }

    public void takeBulletHit() {
        if (shieldStrength > 0) {
            shieldStrength--;


        }
    }

    public double getPlayerSpeed() {
        return playerSpeed;
    }

    public double getShootSpeed() {
        return shootSpeed;
    }

    public int getShieldStrength() {
        return shieldStrength;
    }

    public int getLevelUpPoints() {
        return levelUpPoints;
    }

    public void activateInvincibility() {
        invincible = true;
        // Schedule a task to deactivate invincibility after a certain duration
        Timer timer = new Timer(INVINCIBILITY_DURATION, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                invincible = false; // Deactivate invincibility after duration
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    public boolean isInvincible() {
        return invincible;
    }
}



