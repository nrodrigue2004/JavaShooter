package FinalProject;

import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.sounds.ReusableClip;

import java.awt.event.KeyEvent;

public class Bullet extends Sprite {

    private static final ReusableClip SHOOT_SOUND = new ReusableClip("blaster.wav");

    public Bullet(SpriteComponent sc, Sprite sp, int direction) {
        super(sc);
        setPicture(Game.makeBall(Game.BULLET_COLOR, Game.SMALL));
        setInitialPosition(sp, direction);

    }

    public Bullet(SpriteComponent sc, Player sp, int x, int y) {
        super(sc);
        setPicture(Game.makeBall(Game.BULLET_COLOR, Game.SMALL));
        setInitialPosition(sp, x, y);

    }

    public void setInitialPosition(Sprite sp, int direction) {
        switch (direction) {
            case KeyEvent.VK_DOWN:
                setCenterX(sp.centerX());
                setCenterY(sp.centerY() + sp.getHeight() / 2);
                setVel(0, 2.0);
                break;
            case KeyEvent.VK_UP:
                setCenterX(sp.centerX());
                setCenterY(sp.centerY() - sp.getHeight() / 2);
                setVel(0, -2.0);
                break;
            case KeyEvent.VK_RIGHT:
                setCenterX(sp.centerX() + sp.getWidth() / 2);
                setCenterY(sp.centerY());
                setVel(2.0, 0);
                break;
            case KeyEvent.VK_LEFT:
                setCenterX(sp.centerX() - sp.getWidth() / 2);
                setCenterY(sp.centerY());
                setVel(-2.0, 0);
                break;
        }

    }

    public void setInitialPosition(Player sp, int x, int y) {
        setX(sp.getX() + (Game.BIG - Game.SMALL) / 2);
        setY(sp.getY() + (Game.BIG - Game.SMALL) / 2);
        double delx = x - sp.getX() - sp.getWidth() / 2;
        double dely = y - sp.getY() - sp.getHeight() / 2;
        double dist = Math.sqrt(delx * delx + dely * dely);
        setVel(2 * delx / dist, 2 * dely / dist);

        double bulletSpeed = sp.getShootSpeed();
        setVel(bulletSpeed * delx / dist, bulletSpeed * dely / dist);

    }

    public void update(Game game) {
        if (getX() < 0 || getX() > Game.BOARD_SIZE.width || getY() < 0 || getY() > Game.BOARD_SIZE.height) {
            setActive(false);
        }

    }
}

