package FinalProject;

import basicgraphics.SpriteComponent;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class NewLevels {
    
    private static int totalEnemies = Game.ENEMIES;
    private static int totalBosses = 1;
    private static int Enemy2count = 1;
    public static void progressToNextLevel(SpriteComponent sc, Player player) {
        Enemy2 enemy2 = new Enemy2(sc, player);
        player.activateInvincibility();

        sc.clearSprites();


        player = new Player(sc);

        player.setPicture(Game.makeBall(Game.SHOOTER_COLOR, Game.BIG));
        player.setX(Game.BOARD_SIZE.width / 2);
        player.setY(Game.BOARD_SIZE.height / 2);



        player.setVelX(0);
        player.setVelY(0);

        player.resetPosition();

        sc.removeMouseListener(player);

        setupInputListeners(sc, player);


        for (int i = 0; i < totalEnemies; i++) {
            new Enemies(sc, player);
        }
        for (int i = 0; i < Enemy2count; i++) {
            new Enemy2(sc,player);
            enemy2.moveEnemy();
        }

        for (int i = 0; i < totalBosses; i++) {
            new Boss(sc, player);
        }

        Enemies.enemyCount = totalEnemies;
        Boss.bossCount = totalBosses;

        totalEnemies += 2;
        totalBosses++;
        Enemy2count++;

        final Player finalPlayer = player;
        Thread gameLoopThread = new Thread(() -> runGameLoop(finalPlayer));
        gameLoopThread.start();


    }
    public static void restartGame(SpriteComponent sc, Player player) {
        sc.clearSprites();

        player = new Player(sc);


        player.setPicture(Game.makeBall(Game.SHOOTER_COLOR, Game.BIG));
        player.setX(Game.BOARD_SIZE.width / 2);
        player.setY(Game.BOARD_SIZE.height / 2);


        player.setVelX(0);
        player.setVelY(0);

        player.resetPosition();

        sc.removeMouseListener(player);
        setupInputListeners(sc, player);

        for (int i = 0; i < Game.ENEMIES; i++) {
            new Enemies(sc, player);
        }

        new Boss(sc, player);

        Enemies.enemyCount = Game.ENEMIES;
        Boss.bossCount = 1;

        final Player finalPlayer = player;
        Thread gameLoopThread = new Thread(() -> runGameLoop(finalPlayer));
        gameLoopThread.start();
    }

    static void runGameLoop(Player player) {
        while (true) {
            movePlayer(player);
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    private static void movePlayer(Player player) {
        player.move();
    }



    private static void setupInputListeners(SpriteComponent sc, Player player) {
        sc.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke) {
                handleKeyPressed(ke.getKeyCode(), player);
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                handleKeyReleased(ke.getKeyCode(), player);
            }
        });
        sc.requestFocusInWindow();

        sc.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                new Bullet(sc, player, me.getX(), me.getY());
                Game.playShootSound();
            }
        });
    }

    private static void handleKeyPressed(int keyCode, Player player) {
        switch (keyCode) {
            case KeyEvent.VK_W:
                player.setVelY(-2);
                break;
            case KeyEvent.VK_S:
                player.setVelY(2);
                break;
            case KeyEvent.VK_A:
                player.setVelX(-2);
                break;
            case KeyEvent.VK_D:
                player.setVelX(2);
                break;
            case KeyEvent.VK_SPACE:
                new Bullet(Game.sc, player, KeyEvent.VK_SPACE);
                break;
        }
    }

    private static void handleKeyReleased(int keyCode, Player player) {
        switch (keyCode) {
            case KeyEvent.VK_W:
            case KeyEvent.VK_S:
                player.setVelY(0);
                break;
            case KeyEvent.VK_A:
            case KeyEvent.VK_D:
                player.setVelX(0);
                break;
        }
    }
}
