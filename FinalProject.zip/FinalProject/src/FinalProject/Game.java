package FinalProject;

import basicgraphics.*;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import static FinalProject.Boss.bossCount;
import static FinalProject.Enemies.enemyCount;
import static FinalProject.Player.shieldStrength;
import static javax.swing.JOptionPane.YES_NO_OPTION;


public class Game {

    static int bulletcount = 0;

    public static final double BULLET_SPEED = 3.0;
    private static final ReusableClip SHOOT_SOUND = new ReusableClip("blaster.wav");

    private static Player player;

    static SpriteComponent sc;
    private static Boss boss;
    final public static Random RAND = new Random();
    final public static Color SHOOTER_COLOR = Color.green;
    final public static Color BULLET_COLOR = Color.red;
    final public static Color BULLET_COLOR2 = Color.blue;
    final public static Color ENEMY_COLOR = Color.yellow;
    final public static Color EXPLOSION_COLOR = Color.orange;
    final public static int BIG = 20;
    final public static int SMALL = 5;
    public static int ENEMIES = 5;
    final public static Dimension BOARD_SIZE = new Dimension(1500, 1000);

    static BasicFrame bf = new BasicFrame("Shooter!");


    static Picture makeBall(Color color, int size) {
        Image im = BasicFrame.createImage(size, size);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillOval(0, 0, size, size);
        return new Picture(im);
    }


    public static void run() {
        sc = new SpriteComponent();
        setupInputListeners(sc);
        sc.setPreferredSize(BOARD_SIZE);
        String[][] layout = {{"center"}};
        bf.setStringLayout(layout);
        bf.add("center", sc);
        player = new Player(sc);

        for (int i = 0; i < ENEMIES; i++) {
            Enemies en = new Enemies(sc, player);
        }
        KeyAdapter key = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke) {
                new Bullet(sc, player, ke.getKeyCode());
            }
        };
        bf.addKeyListener(key);
        bf.addMenuAction("Help", "About", new Runnable() {
            @Override
            public void run() {
                JOptionPane.showMessageDialog(bf.getContentPane(), "Have fun!");
            }
        });
        bf.addMenuAction("Help", "New Game", new Runnable() {
            @Override
            public void run() {
                JOptionPane.showMessageDialog(bf.getContentPane(), "Have fun!");
            }
        });
        bf.addMenuAction("File", "Load", new Runnable() {
            @Override
            public void run() {
                JOptionPane.showMessageDialog(bf.getContentPane(), "Have fun!");
            }
        });
        bf.addMenuAction("File", "Store", new Runnable() {
            @Override
            public void run() {
                JOptionPane.showMessageDialog(bf.getContentPane(), "Have fun!");
            }
        });
        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                new Bullet(sc, player, me.getX(), me.getY());
                playShootSound();
            }
        };
        sc.addMouseListener(ma);

        sc.addSpriteSpriteCollisionListener(Enemies.class, Player.class, new SpriteSpriteCollisionListener<Enemies, Player>() {
            @Override
            public void collision(Enemies sp1, Player sp2) {
                player.takeBulletHit();
                sp1.setActive(false);
                if (shieldStrength <= 0 || !sp2.isInvincible()){
                    sp2.setActive(false);
                } else {
                    sp2.setActive(true);
                }
                int choice =JOptionPane.showConfirmDialog(sc, "You lose! Do you want to retry?", "Game Over", YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    NewLevels.restartGame(sc,player);

                } else {
                    System.exit(0);
                }
            }
        });
        sc.addSpriteSpriteCollisionListener(Enemy2.class, Player.class, new SpriteSpriteCollisionListener<Enemy2, Player>() {
            @Override
            public void collision(Enemy2 sp1, Player sp2) {
                player.takeBulletHit();
                sp1.setActive(false);
                if (shieldStrength <= 0 || !sp2.isInvincible()){
                    sp2.setActive(false);
                } else {
                    sp2.setActive(true);
                }
                int choice =JOptionPane.showConfirmDialog(sc, "You lose! Do you want to retry?", "Game Over", YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    NewLevels.restartGame(sc,player);

                } else {
                    System.exit(0);
                }
            }
        });
        sc.addSpriteSpriteCollisionListener(Enemy2.class, Bullet.class, new SpriteSpriteCollisionListener<Enemy2, Bullet>() {
            @Override
            public void collision(Enemy2 sp1, Bullet sp2) {
                sp1.setActive(false);
                sp2.setActive(false);
            }
        });

        sc.addSpriteSpriteCollisionListener(Enemies.class, Bullet.class, new SpriteSpriteCollisionListener<Enemies, Bullet>() {
            @Override
            public void collision(Enemies sp1, Bullet sp2) {
                Enemies.clip.play();
                sp1.setActive(false);
                sp2.setActive(false);
                if (bossCount == 0 && enemyCount == 0) {
                    player.activateInvincibility();
                    JOptionPane.showMessageDialog(sc, "You win! Game Over!");
                    Object[] options = {"Continue to the Next Level"};
                    int choice = JOptionPane.showOptionDialog(sc, "Do you want to continue to the next level?", "Continue", YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                    if (choice == JOptionPane.YES_OPTION) {
                        player.earnLevelUpPoint();
                        String[] upgradeOptions = {"Player Speed", "Bullet Speed", "Shield Strength"};
                        String upgradeChoice = (String) JOptionPane.showInputDialog(sc, "Choose an attribute to upgrade:", "Level Up",
                                JOptionPane.PLAIN_MESSAGE, null, upgradeOptions, upgradeOptions[0]);

                        if (upgradeChoice != null) {
                            player.upgradeAttribute(upgradeChoice.toLowerCase());
                        }
                        NewLevels.progressToNextLevel(sc,player);
                        player.activateInvincibility();
                        JOptionPane.showMessageDialog(sc, "Your current upgrades:\n" +
                                "Player Speed: " + player.getPlayerSpeed() + "\n" +
                                "Bullet Speed: " + player.getShootSpeed() + "\n" +
                                "Shield Strength: " + player.getShieldStrength() + "\n" +
                                "Level Up Points: " + player.getLevelUpPoints());


                    } else {
                        System.exit(0);
                    }
                }
            }
        });
        sc.addSpriteSpriteCollisionListener(Boss.class, Bullet.class, new SpriteSpriteCollisionListener<Boss, Bullet>() {
            @Override
            public void collision(Boss sp1, Bullet sp2) {
                Enemies.clip.play();
                sp2.setActive(false);

                boss.hitPoints--;
                if (boss.hitPoints <= 0) {
                    sp1.setActive(false);
                    bossCount--;
                    if (bossCount == 0 && enemyCount == 0) {
                        player.activateInvincibility();

                        JOptionPane.showMessageDialog(sc, "You win! Game Over!");
                        Object[] options = {"Continue to the Next Level"};
                        int choice = JOptionPane.showOptionDialog(sc, "Do you want to continue to the next level?", "Continue", YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                        if (choice == JOptionPane.YES_OPTION) {
                            player.earnLevelUpPoint();
                            String[] upgradeOptions = {"Player Speed", "Bullet Speed", "Shield Strength"};
                            String upgradeChoice = (String) JOptionPane.showInputDialog(sc, "Choose an attribute to upgrade:", "Level Up",
                                    JOptionPane.PLAIN_MESSAGE, null, upgradeOptions, upgradeOptions[0]);

                            if (upgradeChoice != null) {
                                player.upgradeAttribute(upgradeChoice.toLowerCase());

                            }

                            NewLevels.progressToNextLevel(sc, player);
                            player.activateInvincibility();

                        } else {
                            System.exit(0);
                        }
                    }
                }
        }

        });
        sc.addSpriteSpriteCollisionListener(Boss.class, Player.class, new SpriteSpriteCollisionListener<Boss, Player>() {
            @Override
            public void collision(Boss sp1, Player sp2) {
                player.takeBulletHit();

                sp1.setActive(false);
                if (shieldStrength <= 0 || !sp2.isInvincible()){
                    sp2.setActive(false);
                } else {
                    sp2.setActive(true);
                }
                int choice =JOptionPane.showConfirmDialog(sc, "You lose! Do you want to retry?", "Game Over", YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    NewLevels.restartGame(sc,player);
                } else {
                    System.exit(0);
                }
            }
        });

        sc.addSpriteSpriteCollisionListener(Bullet2.class, Player.class, new SpriteSpriteCollisionListener<Bullet2, Player>() {
            @Override
            public void collision(Bullet2 sp1, Player sp2) {
                player.takeBulletHit();
                sp1.setActive(false);
                if (shieldStrength <= 0 || !sp2.isInvincible()){
                    sp2.setActive(false);
                } else {
                    sp2.setActive(true);
                }
                int choice =JOptionPane.showConfirmDialog(sc, "You lose! Do you want to retry?", "Game Over", YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    NewLevels.restartGame(sc, player);

                } else {
                    System.exit(0);
                }
            }
        });

        boss = new Boss(sc, player);

        class BossShootTask extends Task implements Runnable {
            public void run() {
                bossShootAtPlayer();
            }
    }

        bf.show();
        ClockWorker.initialize(10);
        ClockWorker.addTask(sc.moveSprites());
        if (enemyCount == 1) {
            ClockWorker.addTask(new BossShootTask());
            boss.shootAtPlayer();
        }
        while (true) {

            player.move();
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
                ;
            }
        }
    }


    static void setupInputListeners(SpriteComponent sc) {
        bf.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke) {
                handleKeyPressed(ke.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                handleKeyReleased(ke.getKeyCode());
            }
        });

        sc.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                new Bullet(sc, player, me.getX(), me.getY());
                bulletcount++;

            }
        });
    }

    static void handleKeyPressed(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_W:
                player.setVelY(-2);
                break;
            case KeyEvent.VK_S:
                player.setVelY(2);
                break;
            case KeyEvent.VK_A:
                player.setVelX(-2);
                break;
            case KeyEvent.VK_D:
                player.setVelX(2);
                break;
            case KeyEvent.VK_SPACE:
                new Bullet(sc, player, KeyEvent.VK_SPACE);
                break;
        }
    }

    static void handleKeyReleased(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_W:
            case KeyEvent.VK_S:
                player.setVelY(0);
                break;
            case KeyEvent.VK_A:
            case KeyEvent.VK_D:
                player.setVelX(0);
                break;
        }
    }

    public static void bossShootAtPlayer() {
        if (boss != null) {
            boss.shootAtPlayer();
        }
    }



    public static void playShootSound() {
        SHOOT_SOUND.play();
    }

    public static void main(String[] args) {
        Game g = new Game();
        g.run();
    }
}

