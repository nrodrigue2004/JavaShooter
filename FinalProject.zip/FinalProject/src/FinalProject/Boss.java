package FinalProject;

import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Timer;
import java.util.TimerTask;

public class Boss extends Sprite {
    static int bossCount = 1;
    static int hitPoints;

    private static final int BOSS_SIZE = 100;
    private final Player player;

    public Boss(SpriteComponent sc, Player player) {
        super(sc);
        hitPoints = 5;
        this.player = player;
        bossCount++;
        setPicture(makeBoss());
        setSpecificPosition();
        setRandomVelocity();

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                shootAtPlayer();
            }
        }, 0, 2000);
    }



    private void setSpecificPosition() {
        int startX = 100;
        int startY = 100;
        setX(startX);
        setY(startY);

    }


    private void setRandomVelocity() {
        setVel(2 * Game.RAND.nextDouble() - 1, 2 * Game.RAND.nextDouble() - 1);
    }


    Picture makeBoss() {
        int size = Game.BIG * 3;
        BufferedImage bossImage = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics g = bossImage.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, size, size);
        return new Picture(bossImage);

    }


    public void processEvent(SpriteCollisionEvent se) {
        if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
            double newX = getX();
            double newY = getY();


            if (se.xlo || se.xhi) {
                newX = Math.min(Math.max(newX, 0), getSpriteComponent().getSize().width - getWidth());
                setVel(-getVelX(), getVelY());
            }

            if (se.ylo || se.yhi) {
                newY = Math.min(Math.max(newY, 0), getSpriteComponent().getSize().height - getHeight());
                setVel(getVelX(), -getVelY());
            }


            setX(newX);
            setY(newY);
        }
    }


    public void shootAtPlayer() {
        if (isActive() && player != null) {

            double deltaX = player.getCenterX() - getCenterX();
            double deltaY = player.getCenterY() - getCenterY();
            double angle = Math.atan2(deltaY, deltaX);

            double bulletX = getCenterX() + (Math.cos(angle) * (getWidth() / 2));
            double bulletY = getCenterY() + (Math.sin(angle) * (getHeight() / 2));


            Bullet2 bullet2 = new Bullet2(getSpriteComponent(), this, (int) angle);
            bullet2.setInitialPosition(bulletX, bulletY); // Set the starting position of the bullet
            bullet2.setVel(Game.BULLET_SPEED * Math.cos(angle), Game.BULLET_SPEED * Math.sin(angle));
        }
    }
}

