package FinalProject;
//This game is an infinite roguelike that keeps going each time you complete a level. After each level, you'll earn a level up point
// You can use these points to either upgrade your shield, bullet speed, or player speed.
// There is no end goal, just try to make it as far as you can!
// Move around with wasd and shoot with left mouse click
// There are 3 different enemy types: Bosses, regular enemies, and chaser enemies.
